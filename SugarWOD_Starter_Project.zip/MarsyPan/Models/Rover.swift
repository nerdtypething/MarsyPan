//
//  Rover.swift
//  MarsyPan
//
//  Created by Ruben Hansen-Rojas on 12/29/21.
//

import Foundation

struct Rover {
    let imageName: String
    let name: String
}
