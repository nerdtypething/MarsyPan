//
//  RoverCam.swift
//  MarsyPan
//
//  Created by Ruben Hansen-Rojas on 12/29/21.
//

import Foundation

struct RoverCam {
    let name: String
}
