//
//  MarsyNavigationController.swift
//  MarsyPan
//
//  Created by Ruben Hansen-Rojas on 12/29/21.
//

import Foundation
import UIKit

class MarsyNavigationController: UINavigationController {
    
}

